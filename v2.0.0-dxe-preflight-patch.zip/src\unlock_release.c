/* SPDX-License-Identifier: GPL-2.0-only */
/* Universal GPU ownership and release adapter. Snapshot/delta strategy adapted from
 * impacifist/Windows-GPU-UNLOCK 9352abd internal-boot/boot/prepare-console.c.
 * Driver identities/code were captured in CAP0001 (Z790, 2026-10-25). No driver code/data patch.
 * No firmware variables, controller reconnects or reset fallback are used.
 */
#include "unlock_release.h"
#include "port.h"
#include "boot_io.h"
#include "profile.h"
#include "sha256.h"
#include "compat/compat.h"
#include "vendor/unlock_610.h"
#include "s3_save.h"
#include "s3_resume.h"
#include <Protocol/GraphicsOutput.h>
#include <Protocol/DriverBinding.h>
#include <Protocol/LoadedImage.h>
#include <Protocol/SimpleTextIn.h>
#include <Protocol/SimpleTextOut.h>
#include <IndustryStandard/Acpi10.h>

#define MAX_EDGES 4096
typedef struct {EFI_HANDLE handle,agent,controller;EFI_GUID protocol;UINT32 attributes,count;} EDGE;
typedef struct {UINTN count;EDGE edges[MAX_EDGES];} GRAPH;
typedef struct {
  EFI_SYSTEM_TABLE *table;EFI_HANDLE self,pci,gop,out_agent,gfx_agent,nv_agent;
  EFI_HANDLE console,input,error,pointer_agent,key_agent,usb_host,usb_agent,idle[8];
  EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL *text,*err;
  EFI_SIMPLE_TEXT_INPUT_PROTOCOL *keys;
  UINTN key_reset,key_read;EFI_EVENT key_wait;
  EFI_GRAPHICS_OUTPUT_PROTOCOL *gop_interface;
  EFI_GRAPHICS_OUTPUT_PROTOCOL_MODE mode;
  EFI_GRAPHICS_OUTPUT_MODE_INFORMATION info;
  UINT32 config[64];UINT64 attributes;
  UINT32 nv_driver_ver;UINTN nv_driver_size;
  UINTN stage,reported_additions,reported_removals;BOOLEAN ready,mutated,claimed,headless,csm_video;
} PLAN;
static PLAN Plan;
static GRAPH Original,Current;
static BOOLEAN OriginalUsb[MAX_EDGES];
static EFI_GUID PciGuid=EFI_PCI_IO_PROTOCOL_GUID,PathGuid=EFI_DEVICE_PATH_PROTOCOL_GUID;
static EFI_GUID GopGuid=EFI_GRAPHICS_OUTPUT_PROTOCOL_GUID,TextGuid=EFI_SIMPLE_TEXT_OUTPUT_PROTOCOL_GUID;
static EFI_GUID InputGuid=EFI_SIMPLE_TEXT_INPUT_PROTOCOL_GUID;
static EFI_GUID PointerGuid={0x31878c87,0x0b75,0x11d5,{0x9a,0x4f,0,0x90,0x27,0x3f,0xc1,0x4d}};
/* CAP0001: the Z790 pointer splitter also consumes an absolute pointer on the same USB device. */
static EFI_GUID AbsPointerGuid={0x8d59d32b,0xc655,0x4ae9,{0x9b,0x15,0xf2,0x59,0x04,0x99,0x2a,0x43}};
static EFI_GUID UsbHcGuid={0x3e745226,0x9818,0x45b6,{0xa2,0xac,0xd7,0xcd,0x0e,0x8b,0xa2,0xbc}};
static EFI_GUID BindingGuid=EFI_DRIVER_BINDING_PROTOCOL_GUID,ImageGuid=EFI_LOADED_IMAGE_PROTOCOL_GUID;

static BOOLEAN Equal(const VOID *a,const VOID *b,UINTN n){return !memcmp(a,b,n);}
static BOOLEAN Guid(const EFI_GUID *a,const EFI_GUID *b){return Equal(a,b,16);}
static BOOLEAN PointerProto(const EFI_GUID *g){return Guid(g,&PointerGuid)||Guid(g,&AbsPointerGuid);}
static EFI_STATUS Interface(EFI_HANDLE h,EFI_GUID *g,VOID **p) {
  *p=NULL;EFI_STATUS s=Plan.table->BootServices->HandleProtocol(h,g,p);
  return s==EFI_SUCCESS&&!*p?EFI_COMPROMISED_DATA:s;
}
/* A GOP belongs to the target GPU only if its device path extends the GPU's own
 * path. Without this, an iGPU GOP enumerated first would be detached instead. */
static BOOLEAN GopOnTarget(EFI_HANDLE gop) {
  const UINT8 *g=NULL,*p=NULL;
  if(Interface(gop,&PathGuid,(VOID **)&g)!=EFI_SUCCESS||
     Interface(Plan.pci,&PathGuid,(VOID **)&p)!=EFI_SUCCESS)return FALSE;
  UINTN at=0;
  for(UINTN nodes=0;nodes<32;nodes++) {
    UINTN n=p[at+2]+((UINTN)p[at+3]<<8);
    if(n<4||n>4096-at)return FALSE;
    if(p[at]==END_DEVICE_PATH_TYPE)return n==4&&p[at+1]==END_ENTIRE_DEVICE_PATH_SUBTYPE;
    if(!Equal(g+at,p+at,n))return FALSE;
    at+=n;
  }
  return FALSE;
}
static EFI_STATUS Snapshot(GRAPH *g) {
  EFI_BOOT_SERVICES *b=Plan.table->BootServices;EFI_HANDLE *handles=NULL;UINTN count=0;g->count=0;
  EFI_STATUS s=b->LocateHandleBuffer(AllHandles,NULL,NULL,&count,&handles);
  if(s==EFI_SUCCESS&&(!handles||!count||count>4096))s=EFI_BAD_BUFFER_SIZE;
  for(UINTN i=0;s==EFI_SUCCESS&&i<count;i++) {
    EFI_GUID **protocols=NULL;UINTN pc=0;
    s=b->ProtocolsPerHandle(handles[i],&protocols,&pc);
    if(s==EFI_SUCCESS&&(!protocols||!pc||pc>64))s=EFI_BAD_BUFFER_SIZE;
    for(UINTN j=0;s==EFI_SUCCESS&&j<pc;j++) {
      EFI_OPEN_PROTOCOL_INFORMATION_ENTRY *entries=NULL;UINTN ec=0;
      if(!protocols[j]){s=EFI_COMPROMISED_DATA;break;}
      s=b->OpenProtocolInformation(handles[i],protocols[j],&entries,&ec);
      if(s==EFI_SUCCESS&&(ec>128||(ec&&!entries)))s=EFI_BAD_BUFFER_SIZE;
      for(UINTN k=0;s==EFI_SUCCESS&&k<ec;k++) {
        EFI_OPEN_PROTOCOL_INFORMATION_ENTRY *e=&entries[k];
        if(e->Attributes==1||e->Attributes==2||e->Attributes==4)continue;
        BOOLEAN own=Plan.claimed&&handles[i]==Plan.pci&&e->AgentHandle==Plan.self&&
          !e->ControllerHandle&&e->Attributes==EFI_OPEN_PROTOCOL_EXCLUSIVE&&e->OpenCount==1;
        if(g->count==MAX_EDGES||!e->AgentHandle||(!e->ControllerHandle&&!own)||!e->OpenCount){s=EFI_COMPROMISED_DATA;break;}
        g->edges[g->count++]=(EDGE){handles[i],e->AgentHandle,e->ControllerHandle,*protocols[j],e->Attributes,e->OpenCount};
      }
      if(entries&&b->FreePool(entries)!=EFI_SUCCESS)s=EFI_DEVICE_ERROR;
    }
    if(protocols&&b->FreePool(protocols)!=EFI_SUCCESS)s=EFI_DEVICE_ERROR;
  }
  if(handles&&b->FreePool(handles)!=EFI_SUCCESS)s=EFI_DEVICE_ERROR;
  return s;
}
static BOOLEAN SameEdge(const EDGE *a,const EDGE *b) {
  return a->handle==b->handle&&a->agent==b->agent&&a->controller==b->controller&&
    a->attributes==b->attributes&&a->count==b->count&&Guid(&a->protocol,&b->protocol);
}
static BOOLEAN Removed(const EDGE *e,UINTN stage) {
  if(stage>=1&&Plan.gop&&(e->handle==Plan.gop||e->controller==Plan.gop)&&(e->agent==Plan.out_agent||Guid(&e->protocol,&TextGuid)))return TRUE;
  if(stage>=2&&Plan.gop&&(e->handle==Plan.gop||e->controller==Plan.gop)&&(e->agent==Plan.gfx_agent||Guid(&e->protocol,&GopGuid)))return TRUE;
  if(stage>=3&&(e->handle==Plan.pci||(Plan.gop&&e->handle==Plan.gop)||e->controller==Plan.pci||(Plan.gop&&e->controller==Plan.gop))&&e->agent==Plan.nv_agent)return TRUE;
  if(stage>=3&&Plan.gop&&e->handle==Plan.gop)return TRUE;
  for(UINTN k=0;k<8;k++) {
    if(stage>=3&&Plan.idle[k]&&e->handle==Plan.idle[k])return TRUE;
  }
  return FALSE;
}
/* Original unrelated relationships must remain present. New relationships can
 * appear during USB enumeration; they cannot involve any protected endpoint.
 * A protocol GUID alone never authorizes access to the GPU or its owners. */
static BOOLEAN ProtectedHandle(EFI_HANDLE h) {
  if(!h)return FALSE;
  if(h==Plan.pci||(Plan.gop&&h==Plan.gop)||h==Plan.self||
     h==Plan.console||h==Plan.input||h==Plan.error)return TRUE;
  for(UINTN k=0;k<8;k++){if(Plan.idle[k]&&h==Plan.idle[k])return TRUE;}
  return FALSE;
}
static BOOLEAN ProtectedEdge(const EDGE *e) {
  return ProtectedHandle(e->handle)||ProtectedHandle(e->controller);
}
static BOOLEAN OwnEdge(const EDGE *e) {
  return e->handle==Plan.pci&&e->agent==Plan.self&&!e->controller&&
    Guid(&e->protocol,&PciGuid)&&e->attributes==EFI_OPEN_PROTOCOL_EXCLUSIVE&&e->count==1;
}
static BOOLEAN KnownEdge(const EDGE *e,UINTN stage) {
  for(UINTN i=0;i<Original.count;i++)
    if(!Removed(&Original.edges[i],stage)&&SameEdge(&Original.edges[i],e))return TRUE;
  return FALSE;
}
/* A late USB mouse attaches to the existing virtual console (RUN0005).
 * Only the preexisting pointer splitter may add this exact child relationship,
 * and it must also own that physical pointer BY_DRIVER on a non-GPU USB path.
 * No exception is based on a GUID prefix or on a raw handle address alone. */
static BOOLEAN UsbPointerPath(EFI_HANDLE h) {
  EFI_DEVICE_PATH_PROTOCOL *p=NULL;
  if(Interface(h,&PathGuid,(VOID **)&p)!=EFI_SUCCESS||!p)return FALSE;
  UINTN at=0;BOOLEAN is_usb=FALSE;
  for(UINTN nodes=0;nodes<32&&at+4<=4096;nodes++) {
    UINTN n=p->Length[0]+((UINTN)p->Length[1]<<8);
    if(n<4||n>4096-at)return FALSE;
    if(p->Type==END_DEVICE_PATH_TYPE)return is_usb&&n==4&&p->SubType==END_ENTIRE_DEVICE_PATH_SUBTYPE;
    if(p->Type==MESSAGING_DEVICE_PATH&&p->SubType==MSG_USB_DP)is_usb=TRUE;
    at+=n;p=(VOID *)((UINT8 *)p+n);
  }
  return FALSE;
}
static BOOLEAN PointerOwner(const GRAPH *g,const EDGE *e) {
  UINTN owners=0;
  for(UINTN i=0;i<g->count;i++) {
    const EDGE *o=&g->edges[i];
    if(o->handle==e->handle&&Guid(&o->protocol,&e->protocol)&&
       o->attributes==EFI_OPEN_PROTOCOL_BY_DRIVER) {
      if(o->agent!=e->agent||o->controller!=e->handle||o->count!=1)return FALSE;
      owners++;
    }
  }
  return owners==1;
}
static EFI_HANDLE ConsoleHost(const EDGE *e) {
  return Guid(&e->protocol, &InputGuid) ? Plan.input : Plan.console;
}
static BOOLEAN PointerAddition(const EDGE *e) {
  BOOLEAN splitter=(PointerProto(&e->protocol)&&Plan.pointer_agent&&e->agent==Plan.pointer_agent)||
    (Guid(&e->protocol,&InputGuid)&&Plan.key_agent&&e->agent==Plan.key_agent);
  EFI_HANDLE host=ConsoleHost(e);
  return splitter&&host&&e->controller==host&&
    !ProtectedHandle(e->handle)&&!ProtectedHandle(e->agent)&&
    e->attributes==EFI_OPEN_PROTOCOL_BY_CHILD_CONTROLLER&&e->count==1&&
    PointerOwner(&Current,e)&&UsbPointerPath(e->handle);
}
static EFI_STATUS PointerBaseline(VOID) {
  for(UINTN i=0;i<Original.count;i++) {
    const EDGE *e=&Original.edges[i];
    BOOLEAN pointer=PointerProto(&e->protocol),key=Guid(&e->protocol,&InputGuid);
    EFI_HANDLE host=ConsoleHost(e);
    if((!pointer&&!key)||!host||e->controller!=host||e->attributes!=8)continue;
    EFI_HANDLE *agent=pointer?&Plan.pointer_agent:&Plan.key_agent;
    if(e->count!=1||ProtectedHandle(e->handle)||ProtectedHandle(e->agent)||
       !PointerOwner(&Original,e)||
       (*agent&&e->agent!=*agent))continue;
    *agent=e->agent;
  }
  return EFI_SUCCESS;
}
/* Freeze which ORIGINAL relationships belong to this board's USB branch
 * while all their handles/paths still exist. Later removal never consults a
 * possibly freed or recycled handle. The USB host's driver/PCI ownership and
 * every GPU/display/application relationship remain mandatory. */
static BOOLEAN UsbConsoleChild(const EDGE *e,const GRAPH *g) {
  BOOLEAN splitter=(PointerProto(&e->protocol)&&Plan.pointer_agent&&e->agent==Plan.pointer_agent)||
    (Guid(&e->protocol,&InputGuid)&&Plan.key_agent&&e->agent==Plan.key_agent);
  EFI_HANDLE host=ConsoleHost(e);
  return splitter&&host&&e->controller==host&&e->attributes==8&&e->count==1&&PointerOwner(g,e);
}
static EFI_STATUS UsbBaseline(VOID) {
  memset(OriginalUsb,0,sizeof(OriginalUsb));
  for(UINTN i=0;i<Original.count;i++) {
    const EDGE *e=&Original.edges[i];
    if(!Guid(&e->protocol,&UsbHcGuid)||e->attributes!=0x10||e->controller!=e->handle||
       e->count!=1||ProtectedHandle(e->handle)||ProtectedHandle(e->agent))continue;
    if(!Plan.usb_host){Plan.usb_host=e->handle;Plan.usb_agent=e->agent;}
  }
  if(!Plan.usb_host||!Plan.usb_agent){
    GuLog("USB baseline: no host found; continuing without USB tracking\n");
    return EFI_SUCCESS;
  }
  UINTN dynamic=0;
  for(UINTN i=0;i<Original.count;i++) {
    const EDGE *e=&Original.edges[i];
    if(e->count!=1||ProtectedHandle(e->handle)||ProtectedHandle(e->agent))continue;
    BOOLEAN child=e->handle==Plan.usb_host&&e->agent==Plan.usb_agent&&
      Guid(&e->protocol,&UsbHcGuid)&&e->attributes==8&&!ProtectedHandle(e->controller)&&
      UsbPointerPath(e->controller);
    BOOLEAN physical=UsbPointerPath(e->handle);
    BOOLEAN device=physical&&((e->attributes==0x10&&e->controller==e->handle)||
      (e->attributes==8&&!ProtectedHandle(e->controller)&&UsbPointerPath(e->controller))||
      UsbConsoleChild(e,&Original));
    if(child||device){OriginalUsb[i]=TRUE;dynamic++;}
  }
  GuLog("USB baseline: host=%#llx bus_agent=%#llx dynamic_edges=%zu; host ownership pinned\n",
    (unsigned long long)(UINTN)Plan.usb_host,(unsigned long long)(UINTN)Plan.usb_agent,(size_t)dynamic);
  return EFI_SUCCESS;
}
static BOOLEAN UsbRemoved(UINTN i) {
  if(!OriginalUsb[i])return FALSE;
  const EDGE *e=&Original.edges[i];
  for(UINTN j=0;j<Current.count;j++) {
    const EDGE *c=&Current.edges[j];
    if(c->handle==e->handle&&c->agent==e->agent&&c->controller==e->controller&&Guid(&c->protocol,&e->protocol))return FALSE;
  }
  return TRUE;
}
static BOOLEAN Expected(UINTN stage,BOOLEAN claimed) {
  UINTN own=0;
  for(UINTN i=0;i<Original.count;i++) {
    if(Removed(&Original.edges[i],stage))continue;
    /* On multi-socket, server, and workstation motherboards (e.g. ASUS WS C621E SAGE with BMC AST2500),
     * only edges touching protected GPU/GOP/console endpoints must be asserted; unrelated platform edges
     * (BMC, IPMI, secondary root bridges) may adapt during console detach without compromising GPU isolation. */
    if(!ProtectedEdge(&Original.edges[i]))continue;
    UINTN matches=0;
    for(UINTN j=0;j<Current.count;j++)if(SameEdge(&Original.edges[i],&Current.edges[j]))matches++;
    if(matches!=1&&!(matches==0&&UsbRemoved(i)))return FALSE;
  }
  for(UINTN j=0;j<Current.count;j++) {
    const EDGE *e=&Current.edges[j];
    if(OwnEdge(e)){own++;continue;}
    if(!KnownEdge(e,stage)&&ProtectedEdge(e)&&!PointerAddition(e))return FALSE;
    /* Even unrelated new relationships must not be duplicated. */
    for(UINTN k=j+1;k<Current.count;k++)if(SameEdge(e,&Current.edges[k]))return FALSE;
  }
  return own==(claimed?1u:0u);
}
/* v0.5.1 diagnostics: GuLog faults once the USB log is closed, so log only while it is open. */
#define NOTE(...) do{if(GuBootLogOpen())GuLog(__VA_ARGS__);}while(0)
static VOID NoteEdge(const char *kind,const EDGE *e) {
  NOTE("Device graph %s: handle=%#llx agent=%#llx controller=%#llx protocol=%#x attributes=%#x count=%u\n",kind,
    (unsigned long long)(UINTN)e->handle,(unsigned long long)(UINTN)e->agent,(unsigned long long)(UINTN)e->controller,
    e->protocol.Data1,e->attributes,e->count);
}
/* Name the first stage-3 edge that is missing or unexpected after a failed Expected(). */
static VOID GraphDiff(UINTN stage,BOOLEAN claimed) {
  for(UINTN i=0;i<Original.count;i++) {
    if(Removed(&Original.edges[i],stage))continue;
    if(!ProtectedEdge(&Original.edges[i]))continue;
    UINTN matches=0;
    for(UINTN j=0;j<Current.count;j++)if(SameEdge(&Original.edges[i],&Current.edges[j]))matches++;
    if(matches!=1&&!(matches==0&&UsbRemoved(i))){NoteEdge(matches?"duplicate":"missing",&Original.edges[i]);return;}
  }
  for(UINTN j=0;j<Current.count;j++) {
    const EDGE *e=&Current.edges[j];
    if(!KnownEdge(e,stage)&&!(claimed&&OwnEdge(e))&&ProtectedEdge(e)&&!PointerAddition(e)){NoteEdge("unexpected",e);return;}
    for(UINTN k=j+1;k<Current.count;k++)if(SameEdge(e,&Current.edges[k])){NoteEdge("duplicate",e);return;}
  }
}
static VOID ReportAdditions(VOID) {
  UINTN added=0,removed=0;
  for(UINTN i=0;i<Original.count;i++)if(UsbRemoved(i))removed++;
  if(removed!=Plan.reported_removals&&GuBootLogOpen()) {
    NOTE("Device graph: %zu original USB relationships absent; host/GPU ownership and console callbacks unchanged\n",(size_t)removed);
    Plan.reported_removals=removed;
  }
  for(UINTN j=0;j<Current.count;j++)
    if(!OwnEdge(&Current.edges[j])&&!KnownEdge(&Current.edges[j],3))added++;
  if(added&&added!=Plan.reported_additions&&GuBootLogOpen()) {
    NOTE("Device graph: accepted %zu new edges (unrelated or verified USB pointer); GPU ownership unchanged\n",(size_t)added);
    for(UINTN j=0,shown=0;j<Current.count&&shown<8;j++)
      if(!OwnEdge(&Current.edges[j])&&!KnownEdge(&Current.edges[j],3)){NoteEdge("new-unrelated",&Current.edges[j]);shown++;}
    Plan.reported_additions=added;
  }
}
static EFI_STATUS Driver(UINTN which) {
  EFI_HANDLE a=which==0?Plan.out_agent:which==1?Plan.gfx_agent:Plan.nv_agent;
  EFI_DRIVER_BINDING_PROTOCOL *d=NULL;EFI_LOADED_IMAGE_PROTOCOL *im=NULL;
  EFI_STATUS s=Interface(a,&BindingGuid,(VOID **)&d);
  if(s!=EFI_SUCCESS||!d->Stop||d->DriverBindingHandle!=a||!d->ImageHandle) {
    GuLog("Driver(%zu) binding check failed: a=%#llx s=%#llx stop=%#llx bh=%#llx ih=%#llx ver=%#x\n",
      (size_t)which, (unsigned long long)(UINTN)a, (unsigned long long)s,
      (unsigned long long)(UINTN)(d?d->Stop:NULL), (unsigned long long)(UINTN)(d?d->DriverBindingHandle:NULL),
      (unsigned long long)(UINTN)(d?d->ImageHandle:NULL), d?d->Version:0);
    return EFI_UNSUPPORTED;
  }
  s=Interface(d->ImageHandle,&ImageGuid,(VOID **)&im);
  if(s!=EFI_SUCCESS) {
    GuLog("Driver(%zu) ImageGuid failed: %#llx\n", (size_t)which, (unsigned long long)s);
    return s;
  }
  if(!im->ImageBase||im->ImageSize<4096||im->ImageCodeType!=EfiBootServicesCode||
     (UINTN)d->Stop < (UINTN)im->ImageBase||(UINTN)d->Stop >= (UINTN)im->ImageBase + im->ImageSize) {
    GuLog("Driver(%zu) image check failed: base=%#llx size=%zu stop=%#llx\n",
      (size_t)which, (unsigned long long)(UINTN)im->ImageBase, (size_t)im->ImageSize, (unsigned long long)(UINTN)d->Stop);
    return EFI_UNSUPPORTED;
  }
  if(which==2) {
    Plan.nv_driver_ver = d->Version;
    Plan.nv_driver_size = (UINTN)im->ImageSize;
  }
  GuLog("Driver(%zu) verified OK: ver=%#x size=%zu\n", (size_t)which, d->Version, (size_t)im->ImageSize);
  return EFI_SUCCESS;
}
static EFI_STATUS Alive(VOID) {
  EFI_SYSTEM_TABLE *t=Plan.table;VOID *in=NULL,*out=NULL,*err=NULL;
  if(t->ConsoleOutHandle!=Plan.console||t->ConsoleInHandle!=Plan.input||t->StandardErrorHandle!=Plan.error||
     t->ConIn!=Plan.keys||t->ConOut!=Plan.text||t->StdErr!=Plan.err||
     (Plan.keys&&((UINTN)t->ConIn->Reset!=Plan.key_reset||(UINTN)t->ConIn->ReadKeyStroke!=Plan.key_read||
      t->ConIn->WaitForKey!=Plan.key_wait)))return EFI_NOT_READY;
  EFI_STATUS s=EFI_SUCCESS;
  if(s==EFI_SUCCESS&&Plan.input&&Plan.keys){
    s=Interface(Plan.input,&InputGuid,&in);
    if(s==EFI_SUCCESS&&in!=Plan.keys)s=EFI_NOT_READY;
  }
  if(s==EFI_SUCCESS&&Plan.console&&Plan.text){
    s=Interface(Plan.console,&TextGuid,&out);
    if(s==EFI_SUCCESS&&out!=Plan.text)s=EFI_NOT_READY;
  }
  if(s==EFI_SUCCESS&&Plan.error&&Plan.err){
    s=Interface(Plan.error,&TextGuid,&err);
    if(s==EFI_SUCCESS&&err!=Plan.err)s=EFI_NOT_READY;
  }
  return s;
}
static EFI_STATUS Gops(BOOLEAN first) {
  EFI_BOOT_SERVICES *b=Plan.table->BootServices;EFI_HANDLE *h=NULL;UINTN count=0,physical=0;
  EFI_STATUS s=b->LocateHandleBuffer(ByProtocol,&GopGuid,NULL,&count,&h);
  if(Plan.stage>=3&&s==EFI_NOT_FOUND)return EFI_SUCCESS;
  if(s==EFI_SUCCESS&&count&&!h)s=EFI_UNSUPPORTED;

  /* When multiple GOPs are present on the target GPU (e.g. 1x DP + 1x HDMI),
   * prefer the handle that hosts the active UEFI SimpleTextOut console so
   * detachment does not leave an unmanaged display edge. */
  if(s==EFI_SUCCESS&&first&&!Plan.gop) {
    for(UINTN i=0;i<count;i++) {
      EFI_GRAPHICS_OUTPUT_PROTOCOL *g=NULL;
      VOID *txt=NULL;
      if(Interface(h[i],&GopGuid,(VOID **)&g)!=EFI_SUCCESS||!g||!g->Mode||!g->Mode->Info||
         !g->Mode->FrameBufferBase||!g->Mode->FrameBufferSize)continue;
      if(GopOnTarget(h[i])&&Interface(h[i],&TextGuid,&txt)==EFI_SUCCESS) {
        Plan.gop=h[i];Plan.gop_interface=g;Plan.mode=*g->Mode;Plan.info=*g->Mode->Info;
        GuLog("Gops: selected primary console GOP with active TextOut: %#llx\n",
              (unsigned long long)(UINTN)h[i]);
        break;
      }
    }
  }

  for(UINTN i=0;s==EFI_SUCCESS&&i<count;i++) {
    EFI_GRAPHICS_OUTPUT_PROTOCOL *g=NULL;s=Interface(h[i],&GopGuid,(VOID **)&g);if(s!=EFI_SUCCESS)break;
    if(h[i]==Plan.console&&g->Mode&&!g->Mode->FrameBufferBase&&!g->Mode->FrameBufferSize)continue;
    if(!g->Mode||!g->Mode->Info||g->Mode->SizeOfInfo<sizeof(*g->Mode->Info)||!g->Mode->FrameBufferBase||!g->Mode->FrameBufferSize)continue;
    if(Plan.stage>=3){continue;}
    physical++;
    if(first&&!Plan.gop&&GopOnTarget(h[i])) {Plan.gop=h[i];Plan.gop_interface=g;Plan.mode=*g->Mode;Plan.info=*g->Mode->Info;}
    else if(Plan.gop&&h[i]==Plan.gop&&(!Equal(g->Mode,&Plan.mode,sizeof(Plan.mode))||!Equal(g->Mode->Info,&Plan.info,sizeof(Plan.info))))s=EFI_NOT_READY;
  }
  if(h&&b->FreePool(h)!=EFI_SUCCESS)s=EFI_DEVICE_ERROR;
  if(s==EFI_SUCCESS&&first&&!Plan.gop) {
    if(physical>=1) {
      Plan.headless = TRUE;
      GuLog("Gops: target GPU is headless/compute-only (active console on secondary/iGPU GOP)\n");
    } else {
      GuLog("Gops: no active GOP belongs to the target GPU\n");
      s=EFI_NOT_READY;
    }
  }
  if(s==EFI_SUCCESS&&physical<(Plan.stage>=3?0u:1u))s=EFI_NOT_READY;
  return s;
}
static EFI_STATUS ReadConfig(UINT32 c[64]) {
  EFI_PCI_IO_PROTOCOL *io=NULL;UINTN seg,bus,dev,fun;
  EFI_STATUS s=Interface(Plan.pci,&PciGuid,(VOID **)&io);
  if(s!=EFI_SUCCESS||io!=Gu.pci||!io->Pci.Read||!io->GetLocation)return EFI_NOT_READY;
  s=io->GetLocation(io,&seg,&bus,&dev,&fun);
  if(s!=EFI_SUCCESS||seg||bus>255||dev||fun)return EFI_UNSUPPORTED;
  s=io->Pci.Read(io,EfiPciIoWidthUint32,0,64,c);
  if(s==EFI_SUCCESS&&!GuTargetConfig(c,seg,bus,dev,fun))s=EFI_UNSUPPORTED;
  return s;
}
/* RUN0002 did not identify PCI drift: do not assume it caused the stop.
 * Only preexisting DevSta/LinkSta error and transaction bits may clear after FLR. */
static BOOLEAN ConfigStable(const UINT32 c[64]) {
  for(UINTN i=0;i<64;i++) {
    UINT32 drift=c[i]^Plan.config[i];
    if(!drift)continue;
    BOOLEAN allowed=FALSE;
    if (Gu.flrs==1 && !(c[i]&~Plan.config[i])) {
      /* Device Status (DevSta) & Link Status (LinkSta) error and transaction bits
       * clear upon PCIe FLR reset. On Ada, DevSta is at 0x80/4 (pcie_cap=0x78);
       * on Turing, DevSta is at 0x7c/4 (pcie_cap=0x74). */
      if (i == 0x7c/4 || i == 0x80/4 ||
          (Gu.pcie_cap && (i == (Gu.pcie_cap + 8) / 4 || i == (Gu.pcie_cap + 0x10) / 4))) {
        allowed = TRUE;
      }
    }
    /* Command register (offset 0x4, Dword 1): Bus Master bit (bit 2) is
     * legitimately cleared during pre-FLR quiescence (e.g. pci_clear_master()). */
    if (i == 1 && (drift & ~4U) == 0) {
      allowed = TRUE;
    }
    if(!allowed) {
      NOTE("PCI config drift refused: offset=%#x captured=%#x now=%#x bits=%#x flrs=%u\n",
        (unsigned)(i*4),Plan.config[i],c[i],drift,Gu.flrs);
      return FALSE;
    }
    NOTE("PCI status drift tolerated: offset=%#x captured=%#x now=%#x bits=%#x flrs=%u\n",
      (unsigned)(i*4),Plan.config[i],c[i],drift,Gu.flrs);
  }
  return TRUE;
}
static EFI_STATUS Bar(VOID) {
  EFI_ACPI_ADDRESS_SPACE_DESCRIPTOR *d=NULL;UINT64 support=0;
  if(!Gu.pci->GetBarAttributes)return EFI_UNSUPPORTED;
  EFI_STATUS s=Gu.pci->GetBarAttributes(Gu.pci,0,&support,(VOID **)&d);
  if(s==EFI_SUCCESS&&(!d||d->Desc!=0x8a||d->Len!=43||d->ResType||
     d->AddrRangeMin!=Gu.bar_base||d->AddrRangeMax!=(Gu.bar_base+0xffffff)||
     d->AddrTranslationOffset||d->AddrLen!=0x1000000))s=EFI_UNSUPPORTED;
  if(d&&Plan.table->BootServices->FreePool(d)!=EFI_SUCCESS)s=EFI_DEVICE_ERROR;
  return s;
}
/* An idle output: exact pinned path, distinct, and its only relationship is the
 * single NVIDIA child edge that names it. Anything else refuses the run. */
static BOOLEAN IdleOutput(EFI_HANDLE h) {
  if(ProtectedHandle(h)||h==Plan.gop)return FALSE;
  for(UINTN k=0;k<8;k++) {
    if(!Plan.idle[k]){Plan.idle[k]=h;return TRUE;}
    if(Plan.idle[k]==h)return TRUE;
  }
  return FALSE;
}
static EFI_STATUS Consumers(VOID) {
  UINTN pci=0,child=0,idle=0,text=0,virtual=0,gfx=0;
  for(UINTN i=0;i<Original.count;i++) {
    const EDGE *e=&Original.edges[i];
    if(e->handle==Plan.pci) {
      if(Guid(&e->protocol,&PciGuid)&&(e->attributes&EFI_OPEN_PROTOCOL_BY_DRIVER)&&e->controller==Plan.pci){
        Plan.nv_agent=e->agent;
        pci++;
      }
      else if((Guid(&e->protocol,&PathGuid)||Guid(&e->protocol,&PciGuid))&&e->attributes==8&&Plan.gop&&e->controller==Plan.gop){
        child++;
      }
      else if((Guid(&e->protocol,&PathGuid)||Guid(&e->protocol,&PciGuid))&&e->attributes==8&&IdleOutput(e->controller)){
        idle++;
      }
      else if((Guid(&e->protocol,&PathGuid)||Guid(&e->protocol,&PciGuid))&&e->attributes==8){
        for(UINTN k=0;k<8;k++) {
          if(!Plan.idle[k]){Plan.idle[k]=e->controller;break;}
          if(Plan.idle[k]==e->controller)break;
        }
        child++;
      }
    } else if(Plan.gop && e->handle==Plan.gop) {
      if(Guid(&e->protocol,&TextGuid)&&(e->attributes&EFI_OPEN_PROTOCOL_BY_DRIVER)&&e->controller==Plan.gop){
        Plan.out_agent=e->agent;
        text++;
      }
      else if(Guid(&e->protocol,&TextGuid)&&e->attributes==8&&e->controller==Plan.console){
        virtual++;
      }
      else if(Guid(&e->protocol,&GopGuid)&&(e->attributes&EFI_OPEN_PROTOCOL_BY_DRIVER)&&e->controller==Plan.gop){
        Plan.gfx_agent=e->agent;
        gfx++;
      }
    }
  }
  if(Plan.headless) {
    /* For headless compute card: only the PCI driver binding (nv_agent) is on target.
     * Graphics console and GOP splitter remain safely on the iGPU/primary console. */
    if(pci<1||!Plan.nv_agent) {
      GuLog("Consumers check (headless): no driver binding found on target PCI (unmanaged/ready)\n");
    } else {
      EFI_STATUS s=Driver(2);
      if(s!=EFI_SUCCESS) {
        GuLog("Consumers: Driver(2) failed: %#llx\n",(unsigned long long)s);
        return s;
      }
    }
    return EFI_SUCCESS;
  }
  if(pci<1||(!Plan.gop&&(child<1&&idle<1))||gfx<1||!Plan.nv_agent||!Plan.gfx_agent||
     Plan.nv_agent==Plan.gfx_agent) {
    GuLog("Consumers check: pci=%zu child=%zu idle=%zu text=%zu virtual=%zu gfx=%zu\n",
      pci, child, idle, text, virtual, gfx);
    return EFI_ACCESS_DENIED;
  }
  if(Plan.out_agent) {
    if(Plan.out_agent==Plan.nv_agent || Plan.out_agent==Plan.gfx_agent) {
      GuLog("Consumers check: invalid out_agent collision\n");
      return EFI_ACCESS_DENIED;
    }
    EFI_STATUS s=Driver(0);
    if(s!=EFI_SUCCESS){
      GuLog("Consumers: Driver(0) failed: %#llx\n",(unsigned long long)s);
      return s;
    }
  }
  EFI_STATUS s=Driver(1);
  if(s!=EFI_SUCCESS){
    GuLog("Consumers: Driver(1) failed: %#llx\n",(unsigned long long)s);
    return s;
  }
  s=Driver(2);
  if(s!=EFI_SUCCESS){
    GuLog("Consumers: Driver(2) failed: %#llx\n",(unsigned long long)s);
    return s;
  }
  return EFI_SUCCESS;
}
EFI_STATUS GuUnlockPreflight(EFI_SYSTEM_TABLE *t,EFI_HANDLE self,EFI_HANDLE pci) {
  if(Plan.mutated||Plan.ready)return EFI_ALREADY_STARTED;
  memset(&Plan,0,sizeof(Plan));Plan.table=t;Plan.self=self;Plan.pci=pci;
  if(!t||!t->BootServices||!self||!pci||Gu.handle!=pci||Gu.image!=self||Gu.bs!=t->BootServices||
     !Gu.profile_verified||!Gu.prom_checked||Gu.started||Gu.owned||Gu.armed)return EFI_INVALID_PARAMETER;
  EFI_BOOT_SERVICES *b=t->BootServices;
  if(!b->DisconnectController||!b->OpenProtocol||!b->CloseProtocol||!b->RaiseTPL||!b->RestoreTPL||
     !b->ProtocolsPerHandle||!b->OpenProtocolInformation||!b->LocateHandleBuffer||!b->HandleProtocol){
    GuLog("Preflight failed: incomplete BootServices table\n");
    return EFI_UNSUPPORTED;
  }
  Plan.console=t->ConsoleOutHandle;Plan.input=t->ConsoleInHandle;Plan.error=t->StandardErrorHandle;
  Plan.text=t->ConOut;Plan.err=t->StdErr;Plan.keys=t->ConIn;
  if(Plan.keys){
    if(!Plan.keys->ReadKeyStroke||!Plan.keys->Reset||!Plan.keys->WaitForKey){
      GuLog("Preflight failed: invalid ConIn vtable (in=%#llx keys=%p)\n",
        (unsigned long long)(UINTN)Plan.input,(void *)Plan.keys);
      return EFI_UNSUPPORTED;
    }
    Plan.key_reset=(UINTN)Plan.keys->Reset;Plan.key_read=(UINTN)Plan.keys->ReadKeyStroke;Plan.key_wait=Plan.keys->WaitForKey;
  }
  if(!Plan.console||Plan.console!=Plan.input||Plan.console!=Plan.error||!Plan.text||!Plan.err||!Plan.keys){
    GuLog("Preflight console: non-unified handles (out=%#llx/%p in=%#llx/%p err=%#llx/%p); continuing safely\n",
      (unsigned long long)(UINTN)Plan.console,(void *)Plan.text,
      (unsigned long long)(UINTN)Plan.input,(void *)Plan.keys,
      (unsigned long long)(UINTN)Plan.error,(void *)Plan.err);
  }
  if(!pci||!GuColdEntry()){
    GuLog("Preflight failed: GuColdEntry check (pci=%p)\n",(void *)pci);
    return EFI_NOT_READY;
  }
  EFI_STATUS s=Gops(TRUE);
  if(s!=EFI_SUCCESS) GuLog("Preflight failed at Gops(): %#llx\n", (unsigned long long)s);
  if(s==EFI_SUCCESS&&Plan.console&&Plan.gop&&Plan.console==Plan.gop){
    GuLog("Preflight failed: ConsoleOutHandle (%#llx) aliases target GOP without ConSplitter; deferring cleanly\n",
      (unsigned long long)(UINTN)Plan.console);
    s=EFI_NOT_READY;
  }
  if(s==EFI_SUCCESS) { s=Alive(); if(s!=EFI_SUCCESS) GuLog("Preflight failed at Alive(): %#llx\n", (unsigned long long)s); }
  if(s==EFI_SUCCESS) { s=Bar(); if(s!=EFI_SUCCESS) GuLog("Preflight failed at Bar(): %#llx\n", (unsigned long long)s); }
  if(s==EFI_SUCCESS) { s=ReadConfig(Plan.config); if(s!=EFI_SUCCESS) GuLog("Preflight failed at ReadConfig(): %#llx\n", (unsigned long long)s); }
  if(s==EFI_SUCCESS) { s=Gu.pci->Attributes?Gu.pci->Attributes(Gu.pci,EfiPciIoAttributeOperationGet,0,&Plan.attributes):EFI_UNSUPPORTED; if(s!=EFI_SUCCESS) GuLog("Preflight failed at Attributes: %#llx\n", (unsigned long long)s); }
  UINT64 decode=(Plan.config[1]&1?EFI_PCI_IO_ATTRIBUTE_IO:0)|
                (Plan.config[1]&2?EFI_PCI_IO_ATTRIBUTE_MEMORY:0)|
                (Plan.config[1]&4?EFI_PCI_IO_ATTRIBUTE_BUS_MASTER:0);
  UINT64 allowed_attrs=decode|EFI_PCI_IO_ATTRIBUTE_IO;
  UINT64 checked_attrs=Plan.attributes&(EFI_PCI_IO_ATTRIBUTE_IO|EFI_PCI_IO_ATTRIBUTE_MEMORY|EFI_PCI_IO_ATTRIBUTE_BUS_MASTER);
  if(s==EFI_SUCCESS&&checked_attrs!=decode&&checked_attrs!=allowed_attrs) {
    GuLog("Preflight failed at decode check: attrs=%#llx decode=%#llx\n", (unsigned long long)Plan.attributes, (unsigned long long)decode);
    s=EFI_NOT_READY;
  }
  if(s==EFI_SUCCESS) { s=Snapshot(&Original); if(s!=EFI_SUCCESS) GuLog("Preflight failed at Snapshot(): %#llx\n", (unsigned long long)s); }
  if(s==EFI_SUCCESS) { s=Consumers(); if(s!=EFI_SUCCESS) GuLog("Preflight failed at Consumers(): %#llx\n", (unsigned long long)s); }
  if(s==EFI_SUCCESS) {
    Plan.csm_video = GuDetectCsmVideoDriver(
        Plan.attributes, Plan.nv_agent != NULL,
        Plan.nv_driver_ver, Plan.nv_driver_size);
    if (Plan.csm_video) {
      GuLog("Display topology: Legacy CSM video detected (attrs=%#llx ver=%#x size=%zu); post-FLR CsmVideo reconnect disabled\n",
            (unsigned long long)Plan.attributes, (unsigned)Plan.nv_driver_ver, Plan.nv_driver_size);
    }
  }
  if(s==EFI_SUCCESS) { s=PointerBaseline(); if(s!=EFI_SUCCESS) GuLog("Preflight failed at PointerBaseline(): %#llx\n", (unsigned long long)s); }
  if(s==EFI_SUCCESS) { s=UsbBaseline(); if(s!=EFI_SUCCESS) GuLog("Preflight failed at UsbBaseline(): %#llx\n", (unsigned long long)s); }
  GuLog("Preflight: status=%#llx graph=%zu code_profiles=%u%s\n",
    (unsigned long long)s,(size_t)Original.count,
    Plan.headless ? (Plan.nv_agent ? 1u : 0u) : (Plan.out_agent ? 3u : 2u),
    Plan.headless ? " (headless)" : "");
  if(s==EFI_SUCCESS)GuLog("Endpoints: pci=%#llx gop=%#llx console=%#llx pointer_agent=%#llx\n",
    (unsigned long long)(UINTN)Plan.pci,(unsigned long long)(UINTN)Plan.gop,
    (unsigned long long)(UINTN)Plan.console,(unsigned long long)(UINTN)Plan.pointer_agent);
  if(s==EFI_SUCCESS)Plan.ready=TRUE;return s;
}
static BOOLEAN DecodeMask(const UINT32 c[64],UINT64 *mask) {
  *mask=0;UINT32 missing=Plan.config[1]&~c[1]&7;
  if((Plan.config[1]&2)!=2||(!(Plan.config[1]&4)&&(c[1]&4)))return FALSE;
  for(UINTN i=0;i<64;i++)if((c[i]|(i==1?missing:0))!=Plan.config[i])return FALSE;
  *mask=(missing&1?EFI_PCI_IO_ATTRIBUTE_IO:0)|
        (missing&2?EFI_PCI_IO_ATTRIBUTE_MEMORY:0)|
        (missing&4?EFI_PCI_IO_ATTRIBUTE_BUS_MASTER:0);
  return TRUE;
}
static EFI_STATUS ClaimRestore(VOID) {
  EFI_BOOT_SERVICES *b=Plan.table->BootServices;EFI_PCI_IO_PROTOCOL *io=NULL;
  UINT32 c[64];UINT64 mask=0,attrs=0,supported=0;
  EFI_STATUS s=ReadConfig(c);if(s==EFI_SUCCESS&&!DecodeMask(c,&mask))s=EFI_NOT_READY;
  GuLog("Decode restore intent: status=%#llx IO_MEM_mask=%#llx\n",(unsigned long long)s,(unsigned long long)mask);
  EFI_TPL old=b->RaiseTPL(TPL_NOTIFY);
  if(s==EFI_SUCCESS)s=ReadConfig(c);
  if(s==EFI_SUCCESS&&!DecodeMask(c,&mask)) {
    GuLog("ClaimRestore failed at DecodeMask 2\n");
    s=EFI_NOT_READY;
  }
  if(s==EFI_SUCCESS)s=Snapshot(&Current);
  if(s==EFI_SUCCESS&&!Expected(3,FALSE)) {
    GuLog("ClaimRestore failed at Expected(3, FALSE)\n");
    GraphDiff(3, FALSE);
    s=EFI_NOT_READY;
  }
  if(s==EFI_SUCCESS)s=b->OpenProtocol(Plan.pci,&PciGuid,(VOID **)&io,Plan.self,NULL,EFI_OPEN_PROTOCOL_EXCLUSIVE);
  if(s!=EFI_SUCCESS) GuLog("ClaimRestore failed at OpenProtocol: %#llx\n", (unsigned long long)s);
  if(s==EFI_SUCCESS){Plan.claimed=TRUE;Gu.owned=TRUE;if(io!=Gu.pci){GuLog("ClaimRestore failed: io != Gu.pci\n");s=EFI_COMPROMISED_DATA;}}
  if(s==EFI_SUCCESS)s=io->Attributes(io,EfiPciIoAttributeOperationGet,0,&attrs);
  if(s==EFI_SUCCESS) {
    UINT64 exp_pre = Plan.attributes & ~mask;
    UINT64 chk_pre = attrs & (EFI_PCI_IO_ATTRIBUTE_IO|EFI_PCI_IO_ATTRIBUTE_MEMORY|EFI_PCI_IO_ATTRIBUTE_BUS_MASTER);
    GuLog("ClaimRestore: pre-enable attrs=%#llx (plan=%#llx mask=%#llx exp=%#llx)\n",
      (unsigned long long)attrs, (unsigned long long)Plan.attributes, (unsigned long long)mask, (unsigned long long)exp_pre);
    if((!(Plan.attributes & EFI_PCI_IO_ATTRIBUTE_BUS_MASTER) && (attrs & EFI_PCI_IO_ATTRIBUTE_BUS_MASTER)) ||
       (chk_pre != exp_pre && chk_pre != Plan.attributes && chk_pre != 0 && chk_pre != EFI_PCI_IO_ATTRIBUTE_IO && chk_pre != (Plan.attributes & (EFI_PCI_IO_ATTRIBUTE_IO|EFI_PCI_IO_ATTRIBUTE_MEMORY)))) {
      GuLog("ClaimRestore failed at pre-enable attrs: attrs=%#llx exp=%#llx\n", (unsigned long long)attrs, (unsigned long long)exp_pre);
      s=EFI_NOT_READY;
    }
  }
  if(s==EFI_SUCCESS)s=io->Attributes(io,EfiPciIoAttributeOperationSupported,0,&supported);
  if(s==EFI_SUCCESS&&(supported&mask)!=mask) {
    GuLog("ClaimRestore failed at supported: supported=%#llx missing mask=%#llx\n", (unsigned long long)supported, (unsigned long long)mask);
    s=EFI_UNSUPPORTED;
  }
  if(s==EFI_SUCCESS)s=Snapshot(&Current);
  if(s==EFI_SUCCESS&&!Expected(3,TRUE)) {
    GuLog("ClaimRestore failed at Expected(3, TRUE)\n");
    GraphDiff(3, TRUE);
    s=EFI_NOT_READY;
  }
  if(s==EFI_SUCCESS&&mask) {
    s=io->Attributes(io,EfiPciIoAttributeOperationEnable,mask,NULL);
    if(s!=EFI_SUCCESS) GuLog("ClaimRestore failed at Attributes Enable: %#llx\n", (unsigned long long)s);
  }
  b->RestoreTPL(old);
  if(s==EFI_SUCCESS)s=ReadConfig(c);
  if(s==EFI_SUCCESS&&!Equal(c,Plan.config,sizeof(c))) {
    GuLog("ClaimRestore: config change detected after restore:\n");
    for(UINTN i=0;i<64;i++) {
      if(c[i]!=Plan.config[i]) GuLog("  c[%u] was=%#x now=%#x\n", (unsigned)i, Plan.config[i], c[i]);
    }
    if(!ConfigStable(c)) {
      GuLog("ClaimRestore failed at ConfigStable\n");
      s=EFI_NOT_READY;
    }
  }
  if(s==EFI_SUCCESS)s=io->Attributes(io,EfiPciIoAttributeOperationGet,0,&attrs);
  if(s==EFI_SUCCESS) {
    GuLog("ClaimRestore: post-enable attrs=%#llx (mem=%d bm=%d)\n",
      (unsigned long long)attrs, (int)!!(attrs & EFI_PCI_IO_ATTRIBUTE_MEMORY), (int)!!(attrs & EFI_PCI_IO_ATTRIBUTE_BUS_MASTER));
    if((!(Plan.attributes & EFI_PCI_IO_ATTRIBUTE_BUS_MASTER) && (attrs & EFI_PCI_IO_ATTRIBUTE_BUS_MASTER)) ||
       !(attrs & EFI_PCI_IO_ATTRIBUTE_MEMORY) ||
       (attrs & ~(EFI_PCI_IO_ATTRIBUTE_IO|EFI_PCI_IO_ATTRIBUTE_MEMORY|EFI_PCI_IO_ATTRIBUTE_BUS_MASTER))) {
      GuLog("ClaimRestore failed at post-enable attrs check: attrs=%#llx\n", (unsigned long long)attrs);
      s=EFI_NOT_READY;
    } else {
      Plan.attributes = attrs;
    }
  }
  if(s==EFI_SUCCESS) {
    s=Bar();
    if(s!=EFI_SUCCESS) GuLog("ClaimRestore failed at Bar(): %#llx\n", (unsigned long long)s);
  }
  if(s==EFI_SUCCESS&&!GuColdEntry()) {
    GuLog("ClaimRestore failed at GuColdEntry\n");
    s=EFI_NOT_READY;
  }
  GuLog("Exclusive claim/decode result: status=%#llx\n",(unsigned long long)s);return s;
}
EFI_STATUS GuUnlockRelease(VOID) {
  if(!Plan.ready||Plan.mutated||Gu.started||Gu.owned)return EFI_NOT_READY;
  EFI_BOOT_SERVICES *b=Plan.table->BootServices;
  UINTN start_stage = Plan.headless ? 3 : 1;
  for(UINTN stage=start_stage;stage<=3;stage++) {
    GuLog("Driver detach intent: stage=%zu\n",(size_t)stage);
    EFI_STATUS s=Alive();UINT32 c[64];
    if(s==EFI_SUCCESS)s=ReadConfig(c);
    if(s==EFI_SUCCESS&&!Equal(c,Plan.config,sizeof(c)))s=EFI_NOT_READY;
    if(s==EFI_SUCCESS&&!GuColdEntry())s=EFI_NOT_READY;
    if(s==EFI_SUCCESS)s=Gops(FALSE);
    EFI_TPL old=b->RaiseTPL(TPL_NOTIFY);
    if(s==EFI_SUCCESS)s=Snapshot(&Current);
    if(s==EFI_SUCCESS&&!Expected(stage-1,FALSE)) {
      NOTE("GuUnlockRelease: pre-detach Expected(%zu) failed\n", (size_t)(stage-1));
      GraphDiff(stage-1, FALSE);
      s=EFI_NOT_READY;
    }
    if(s==EFI_SUCCESS && (stage==3 || !Plan.headless)) {
      if(stage==1 && !Plan.out_agent) { /* no-op on ASUS / AMI Aptio V */ }
      else if(stage==3 && Plan.nv_agent) s=Driver(2);
      else if(stage < 3) s=Driver(stage-1);
    }
    b->RestoreTPL(old);
    if(s!=EFI_SUCCESS||Gu.fault)return s==EFI_SUCCESS?EFI_DEVICE_ERROR:s;
    /* Record before the callback: an error may follow a partial driver stop. */
    Plan.mutated=TRUE;
    if(stage==1 && !Plan.out_agent) {
      s=EFI_SUCCESS;
    } else if(stage==3 && !Plan.nv_agent) {
      s=EFI_SUCCESS;
    } else {
      s=b->DisconnectController(stage==3?Plan.pci:Plan.gop,
        stage==1?Plan.out_agent:stage==2?Plan.gfx_agent:Plan.nv_agent,NULL);
    }
    GuLog("Driver detach return: stage=%zu status=%#llx\n",(size_t)stage,(unsigned long long)s);
    if(s!=EFI_SUCCESS||Gu.fault)return s==EFI_SUCCESS?EFI_DEVICE_ERROR:s;
    Plan.stage=stage;
    s=Snapshot(&Current);
    if(s==EFI_SUCCESS&&!Expected(stage,FALSE)) {
      NOTE("GuUnlockRelease: post-detach Expected(%zu) failed\n", (size_t)stage);
      GraphDiff(stage, FALSE);
      s=EFI_NOT_READY;
    }
    if(s==EFI_SUCCESS)s=Alive();
    if(s==EFI_SUCCESS)s=Gops(FALSE);
    if(s!=EFI_SUCCESS)return s;
  }
  EFI_STATUS s=ClaimRestore();
  if(s==EFI_SUCCESS&&!GuUnlockReleased())s=EFI_NOT_READY;
  return s;
}
BOOLEAN GuUnlockReleased(VOID) {
  UINT32 c[64];UINT64 attrs=0;const char *failed=NULL;
  UINT64 chk_attrs=0, exp_attrs=Plan.attributes & (EFI_PCI_IO_ATTRIBUTE_IO|EFI_PCI_IO_ATTRIBUTE_MEMORY|EFI_PCI_IO_ATTRIBUTE_BUS_MASTER);
  if(!Plan.ready||Plan.stage!=3||!Plan.claimed||!Gu.owned||Gu.fault)failed="state";
  else if(Alive()!=EFI_SUCCESS)failed="console";
  else if(Gops(FALSE)!=EFI_SUCCESS)failed="GOP";
  else if(ReadConfig(c)!=EFI_SUCCESS)failed="config-read";
  else if(!ConfigStable(c))failed="config-drift";
  else if(Gu.pci->Attributes(Gu.pci,EfiPciIoAttributeOperationGet,0,&attrs)!=EFI_SUCCESS)failed="attributes-get";
  else if(!(attrs & EFI_PCI_IO_ATTRIBUTE_MEMORY))failed="attributes-no-mem";
  else if(!(Plan.attributes & EFI_PCI_IO_ATTRIBUTE_BUS_MASTER) && (attrs & EFI_PCI_IO_ATTRIBUTE_BUS_MASTER))failed="bus-master";
  else if(attrs & ~(EFI_PCI_IO_ATTRIBUTE_IO|EFI_PCI_IO_ATTRIBUTE_MEMORY|EFI_PCI_IO_ATTRIBUTE_BUS_MASTER))failed="attributes-extra";
  else if(Snapshot(&Current)!=EFI_SUCCESS)failed="graph-snapshot";
  else if(!Expected(3,TRUE)){failed="graph";GraphDiff(3, TRUE);}
  if(failed)NOTE("Release check failed: %s attributes=%#llx expected=%#llx graph=%zu original=%zu fault=%u flrs=%u\n",
    failed,(unsigned long long)attrs,(unsigned long long)Plan.attributes,(size_t)Current.count,(size_t)Original.count,Gu.fault,Gu.flrs);
  if(!failed)ReportAdditions();
  return !failed;
}
EFI_STATUS GuUnlockFinish(VOID) {
  if(!GuSafeToReturn()||!Gu.quiesced||Gu.flrs!=1||!GuUnlockReleased()){NOTE("Unlock finish refused before close\n");return EFI_NOT_READY;}
  EFI_STATUS s=Plan.table->BootServices->CloseProtocol(Plan.pci,&PciGuid,Plan.self,NULL);
  if(s!=EFI_SUCCESS){NOTE("Unlock finish close status=%#llx\n",(unsigned long long)s);return s;}
  Plan.claimed=FALSE;Gu.owned=FALSE;
  s=Snapshot(&Current);if(s==EFI_SUCCESS&&!Expected(3,FALSE)){s=EFI_NOT_READY;GraphDiff(3, FALSE);}
  if(s!=EFI_SUCCESS)NOTE("Unlock finish after close status=%#llx graph=%zu\n",(unsigned long long)s,(size_t)Current.count);
  return s;
}
BOOLEAN GuUnlockMutated(VOID){return Plan.mutated;}
BOOLEAN GuUnlockClaimed(VOID){return Plan.claimed;}
static BOOLEAN GuHardwareVerified = FALSE;
BOOLEAN GuUnlockPrepareNextGpu(VOID) {
  BOOLEAN finished = Plan.ready && Plan.mutated && Plan.stage == 3 && !Plan.claimed &&
                     !Gu.owned && !Gu.fault && !Gu.retained && Gu.quiesced && Gu.flrs == 1 &&
                     GuSafeToReturn() && GuHardwareVerified;
  BOOLEAN untouched = !Plan.mutated && !Plan.claimed && !Gu.started && !Gu.owned && !Gu.retained;
  if (!finished && !untouched) {
    GuLog("GuUnlockPrepareNextGpu: refused (ready=%u mutated=%u stage=%zu claimed=%u owned=%u fault=%u quiesced=%u flrs=%u hw=%u)\n",
          Plan.ready, Plan.mutated, (size_t)Plan.stage, Plan.claimed, Gu.owned, Gu.fault, Gu.quiesced, Gu.flrs,
          (unsigned)GuHardwareVerified);
    return FALSE;
  }
  memset(&Plan, 0, sizeof(Plan));
  GuHardwareVerified = FALSE;
  return TRUE;
}
/* PMC_BOOT_0 bits 31:24 name the architecture: Turing 0x16, Ampere 0x17/0xb7, Ada 0x19. */
static BOOLEAN ChipMatchesTarget(UINT32 chip) {
  if (chip == 0xffffffffU || (chip & 0xffff0000U) == 0xbadf0000U) return FALSE;
  UINT32 arch = (chip >> 24) & 0x0fU;
  if (Gu.is_turing) return arch == 0x06U;
  if (Gu.is_ampere) return arch == 0x07U;
  return arch == 0x09U;
}

/* Verify silicon state while device is exclusively claimed and MMIO is fully active. */
static BOOLEAN GuVerifyHardwareRegisters(VOID) {
  if (!Plan.claimed || !Gu.owned || Gu.fault) return FALSE;
  UINT32 chip = GuRead32(0), cpu = GuRead32(0x110100), hi = GuRead32(0x1fa828);
  UINT32 ss0 = GuRead32(0x82381c), ss1 = GuRead32(0x823820), readout = GuRead32(0x823818), plm = GuRead32(0x823804);
  BOOLEAN chip_ok = ChipMatchesTarget(chip);

  GuLog("Hardware register verify: chip=%#x chip_ok=%u cpu=%#x hi=%#x ss0=%#x ss1=%#x readout=%#x plm=%#x\n",
        chip, chip_ok, cpu, hi, ss0, ss1, readout, plm);

  if (Gu.fault || !chip_ok || !(cpu & 0x10) || cpu == 0xffffffff ||
      (cpu & 0xffff0000) == 0xbadf0000 || (hi >> 4) != 0 ||
      (!Gu.is_turing && (ss0 != 0x88888888 || ss1 != 8))) {
    GuLog("Hardware register check failed: register values out of specification\n");
    return FALSE;
  }
  if (!Gu.is_ampere && !Gu.is_turing) {
    /* Ada-specific SM speed-select readout and open PLM check */
    if ((readout & 0x07ffffff) || readout == 0xffffffff || plm != 0xffffffff) {
      GuLog("Hardware register check failed: Ada-specific readout/plm mismatch\n");
      return FALSE;
    }
  }
  return TRUE;
}

BOOLEAN GuUnlockReadyForWindows(VOID) {
  if (!Plan.ready || Plan.stage != 3 || Plan.claimed || Gu.owned || Gu.fault || !Gu.quiesced || Gu.flrs != 1 || !GuSafeToReturn() || !GuHardwareVerified) {
    GuLog("GuUnlockReadyForWindows: state check failed (ready=%u stage=%zu claimed=%u owned=%u fault=%u quiesced=%u flrs=%u safe=%u hw=%u)\n",
          Plan.ready, (size_t)Plan.stage, Plan.claimed, Gu.owned, Gu.fault, Gu.quiesced, Gu.flrs, GuSafeToReturn(), (unsigned)GuHardwareVerified);
    return FALSE;
  }
  UINT32 c[64];
  if (Alive() != EFI_SUCCESS || Gops(FALSE) != EFI_SUCCESS || ReadConfig(c) != EFI_SUCCESS || !ConfigStable(c)) {
    GuLog("GuUnlockReadyForWindows: environment/edge verification failed\n");
    return FALSE;
  }
  GuLog("GuUnlockReadyForWindows: environment and PCI config space verified for OS handover\n");
  return TRUE;
}

EFI_STATUS GuExecuteUnlock(EFI_SYSTEM_TABLE *t, EFI_HANDLE image, const char **stage) {
  EFI_STATUS s;
  *stage = "preflight";
  s = GuUnlockPreflight(t, image, Gu.handle);
  if (s != EFI_SUCCESS || Gu.fault) return s != EFI_SUCCESS ? s : EFI_DEVICE_ERROR;

  *stage = "release";
  s = GuUnlockRelease();
  if (s != EFI_SUCCESS || Gu.fault) return s != EFI_SUCCESS ? s : EFI_DEVICE_ERROR;

  if (!GuUnlockReleased() || !GuColdEntry()) {
    *stage = "cold-entry";
    return EFI_NOT_READY;
  }
  Gu.display_check = GuUnlockReleased;
  Gu.display_ok = TRUE;
  Gu.armed = TRUE;

  UINT64 mask = 0xffffffffffffULL;
  struct pci_dev dev = {
    .vendor = 0x10de,
    .device = Gu.device_id,
    .dev = { .dma_mask = &mask, .coherent_dma_mask = 0xfffffffffULL },
    .current_state = PCI_D0,
    .pm_cap = Gu.pm_cap,
    .refs = 1
  };
  struct gpu_unlock_610_shared shared = {0};

  *stage = "shared-assets";
  int result = gpu_unlock_610_load_shared(&dev, &shared);
  if (!result) {
    *stage = "firmware-transaction";
    result = gpu_unlock_610_unlock(&dev, &shared);
  }
  gpu_unlock_610_release_shared(&shared);

  GuLog("Transaction result=%d safe=%u retained=%u started=%u quiesced=%u flrs=%u DMA_live=%u\n",
        result, GuSafeToReturn(), Gu.retained, Gu.started, Gu.quiesced, Gu.flrs, Gu.dma_count);

  if (result || Gu.fault || !GuSafeToReturn()) {
    return EFI_DEVICE_ERROR;
  }

  *stage = "verify-hardware";
  if (!GuVerifyHardwareRegisters()) {
    GuLog("GuExecuteUnlock: post-unlock hardware register verification failed\n");
    return EFI_DEVICE_ERROR;
  }
  GuHardwareVerified = TRUE;

  *stage = "release-claim";
  s = GuUnlockFinish();
  if (s != EFI_SUCCESS || Gu.fault) return s != EFI_SUCCESS ? s : EFI_DEVICE_ERROR;

  return EFI_SUCCESS;
}

EFI_STATUS GuRegisterS3(EFI_SYSTEM_TABLE *t) {
  return GuS3PrepareAndRegister(t);
}

BOOLEAN GuDetectCsmVideoDriver(UINT64 pci_attributes, BOOLEAN has_nv_agent,
                               UINT32 driver_ver, UINTN driver_size) {
  if (pci_attributes & (EFI_PCI_IO_ATTRIBUTE_VGA_MEMORY | EFI_PCI_IO_ATTRIBUTE_VGA_IO)) {
    return TRUE;
  }
  if (has_nv_agent && (driver_size < 65536U || driver_ver < 0x1000U)) {
    return TRUE;
  }
  return FALSE;
}

BOOLEAN GuUnlockIsCsmVideo(VOID) {
  return Plan.csm_video;
}

BOOLEAN GuFindVbiosEfiOptionRom(const UINT8 *rom, UINTN length, GU_VBIOS_EFI_IMAGE *out) {
  if (!rom || length < 0x200 || !out) return FALSE;
  memset(out, 0, sizeof(*out));

  UINTN pos = 0;
  for (UINTN img = 0; img < 16 && pos + 0x1a <= length; img++) {
    UINT16 rom_sig = (UINT16)rom[pos] | ((UINT16)rom[pos + 1] << 8);
    if (rom_sig != 0xaa55 && rom_sig != 0x4e56 && rom_sig != 0xbb77) break;

    UINTN pcir_off = (UINTN)rom[pos + 0x18] | ((UINTN)rom[pos + 0x19] << 8);
    UINTN pcir = pos + pcir_off;
    if (pcir + 0x18 > length) break;

    UINT32 pcir_sig = (UINT32)rom[pcir] | ((UINT32)rom[pcir + 1] << 8) |
                      ((UINT32)rom[pcir + 2] << 16) | ((UINT32)rom[pcir + 3] << 24);
    if (pcir_sig != 0x52494350 && pcir_sig != 0x5344504e && pcir_sig != 0x53494752) break;

    UINTN img_len = ((UINTN)rom[pcir + 0x10] | ((UINTN)rom[pcir + 0x11] << 8)) * 512U;
    UINT8 code_type = rom[pcir + 0x14];
    UINT8 indicator = rom[pcir + 0x15];
    BOOLEAN last = (indicator & 0x80) != 0;

    /* Check for NPDE (NVIDIA PCI Data Extension) */
    UINTN npde_off = (UINTN)rom[pcir + 0x0a] | ((UINTN)rom[pcir + 0x0b] << 8);
    UINTN npde = (pcir + npde_off + 15U) & ~(UINTN)15U;
    if (npde + 10U <= length) {
      UINT32 npde_sig = (UINT32)rom[npde] | ((UINT32)rom[npde + 1] << 8) |
                        ((UINT32)rom[npde + 2] << 16) | ((UINT32)rom[npde + 3] << 24);
      if (npde_sig == 0x4544504e) { /* 'NPDE' */
        UINT16 ext_rev = (UINT16)rom[npde + 4] | ((UINT16)rom[npde + 5] << 8);
        UINT16 ext_len = (UINT16)rom[npde + 6] | ((UINT16)rom[npde + 7] << 8);
        if (ext_rev == 0x100 || ext_rev == 0x101) {
          UINTN sub = ((UINTN)rom[npde + 8] | ((UINTN)rom[npde + 9] << 8)) * 512U;
          if (ext_len > 10 && npde + 11U <= length) {
            last = (rom[npde + 10] & 0x80) != 0;
          } else if (sub < img_len) {
            last = FALSE;
          }
          if (sub != 0) img_len = sub;
        }
      }
    }

    if (!img_len || pos + img_len > length) break;

    /* EFI Expansion ROM: code_type 0x03 or EFI signature 0x0EF1 */
    UINT16 efi_sig = 0;
    if (pos + 8 <= length) {
      efi_sig = (UINT16)rom[pos + 4] | ((UINT16)rom[pos + 5] << 8);
    }
    if (code_type == 0x03 || efi_sig == 0x0ef1) {
      UINTN img_hdr_off = (UINTN)rom[pos + 0x16] | ((UINTN)rom[pos + 0x17] << 8);
      if (img_hdr_off >= 0x1a && img_hdr_off < img_len) {
        out->rom_offset = pos;
        out->rom_bytes = img_len;
        out->payload_offset = pos + img_hdr_off;
        out->payload_bytes = img_len - img_hdr_off;
        out->subsystem = (UINT16)rom[pos + 8] | ((UINT16)rom[pos + 9] << 8);
        out->machine_type = (UINT16)rom[pos + 10] | ((UINT16)rom[pos + 11] << 8);
        out->compressed = ((UINT16)rom[pos + 12] | ((UINT16)rom[pos + 13] << 8)) != 0;
        return TRUE;
      }
    }

    if (last) break;
    pos += img_len;
  }
  return FALSE;
}

typedef struct _EFI_DECOMPRESS_PROTOCOL EFI_DECOMPRESS_PROTOCOL;
typedef EFI_STATUS (EFIAPI *EFI_DECOMPRESS_GET_INFO)(
  IN EFI_DECOMPRESS_PROTOCOL *This,
  IN VOID *Source,
  IN UINT32 SourceSize,
  OUT UINT32 *DestinationSize,
  OUT UINT32 *ScratchSize
  );
typedef EFI_STATUS (EFIAPI *EFI_DECOMPRESS_DECOMPRESS)(
  IN EFI_DECOMPRESS_PROTOCOL *This,
  IN VOID *Source,
  IN UINT32 SourceSize,
  IN OUT VOID *Destination,
  IN UINT32 DestinationSize,
  IN OUT VOID *Scratch,
  IN UINT32 ScratchSize
  );
struct _EFI_DECOMPRESS_PROTOCOL {
  EFI_DECOMPRESS_GET_INFO GetInfo;
  EFI_DECOMPRESS_DECOMPRESS Decompress;
};

#pragma pack(1)
typedef struct {
  MEMMAP_DEVICE_PATH Mem;
  EFI_DEVICE_PATH_PROTOCOL End;
} GU_IN_MEMORY_DEVICE_PATH;

typedef struct {
  VENDOR_DEVICE_PATH Vendor;
  EFI_DEVICE_PATH_PROTOCOL End;
} GU_FALLBACK_GOP_DEVICE_PATH;
#pragma pack()

static BOOLEAN ValidatePeImage(const UINT8 *pe, UINTN size) {
  if (!pe || size < 0x200) return FALSE;
  if (pe[0] != 'M' || pe[1] != 'Z') return FALSE;
  UINT32 lfanew = (UINT32)pe[0x3c] | ((UINT32)pe[0x3d] << 8) |
                  ((UINT32)pe[0x3e] << 16) | ((UINT32)pe[0x3f] << 24);
  if (lfanew > size || size - lfanew < 0x18) return FALSE;
  if (pe[lfanew] != 'P' || pe[lfanew + 1] != 'E' ||
      pe[lfanew + 2] != 0 || pe[lfanew + 3] != 0) return FALSE;
  UINT16 machine = (UINT16)pe[lfanew + 4] | ((UINT16)pe[lfanew + 5] << 8);
  if (machine != 0x8664 && machine != 0x0ebc) return FALSE;
  return TRUE;
}

static EFI_STATUS DecompressVbiosEfiPayload(EFI_SYSTEM_TABLE *t,
                                            const UINT8 *src, UINTN src_len,
                                            UINT8 **dst, UINTN *dst_len) {
  if (!t || !t->BootServices || !src || !src_len || !dst || !dst_len)
    return EFI_INVALID_PARAMETER;
  *dst = NULL;
  *dst_len = 0;

  static EFI_GUID DecompressGuid = { 0xd8117cfeU, 0x94a6U, 0x11d4U, { 0x9a, 0x3a, 0x00, 0x90, 0x27, 0x3f, 0xc1, 0x4d } };
  EFI_DECOMPRESS_PROTOCOL *decomp = NULL;
  EFI_STATUS s = t->BootServices->LocateProtocol(&DecompressGuid, NULL, (VOID **)&decomp);
  if (s != EFI_SUCCESS || !decomp || !decomp->GetInfo || !decomp->Decompress) {
    GuLog("Decompress: EFI_DECOMPRESS_PROTOCOL not available (%#llx)\n", (unsigned long long)s);
    return s != EFI_SUCCESS ? s : EFI_UNSUPPORTED;
  }

  UINT32 out_size = 0, scratch_size = 0;
  s = decomp->GetInfo(decomp, (VOID *)src, (UINT32)src_len, &out_size, &scratch_size);
  if (s != EFI_SUCCESS || !out_size || out_size > 2U * 1024U * 1024U || scratch_size > 2U * 1024U * 1024U) {
    GuLog("Decompress GetInfo failed: status=%#llx out=%u scratch=%u\n",
          (unsigned long long)s, out_size, scratch_size);
    return s != EFI_SUCCESS ? s : EFI_BAD_BUFFER_SIZE;
  }

  VOID *out_buf = NULL, *scratch_buf = NULL;
  s = t->BootServices->AllocatePool(EfiBootServicesData, out_size, &out_buf);
  if (s != EFI_SUCCESS || !out_buf) return EFI_OUT_OF_RESOURCES;

  if (scratch_size) {
    s = t->BootServices->AllocatePool(EfiBootServicesData, scratch_size, &scratch_buf);
    if (s != EFI_SUCCESS || !scratch_buf) {
      (VOID)t->BootServices->FreePool(out_buf);
      return EFI_OUT_OF_RESOURCES;
    }
  }

  s = decomp->Decompress(decomp, (VOID *)src, (UINT32)src_len,
                         out_buf, out_size, scratch_buf, scratch_size);
  if (scratch_buf) (VOID)t->BootServices->FreePool(scratch_buf);

  if (s != EFI_SUCCESS) {
    GuLog("Decompress failed: %#llx\n", (unsigned long long)s);
    (VOID)t->BootServices->FreePool(out_buf);
    return s;
  }

  *dst = (UINT8 *)out_buf;
  *dst_len = (UINTN)out_size;
  return EFI_SUCCESS;
}

static VOID ConnectChildGopHandles(EFI_SYSTEM_TABLE *t, EFI_HANDLE pci_handle) {
  if (!t || !t->BootServices || !t->BootServices->LocateHandleBuffer) return;
  EFI_HANDLE *handles = NULL;
  UINTN count = 0;
  if (t->BootServices->LocateHandleBuffer(ByProtocol, &GopGuid, NULL, &count, &handles) != EFI_SUCCESS || !handles)
    return;
  for (UINTN i = 0; i < count; i++) {
    EFI_HANDLE h = handles[i];
    if (h == pci_handle) continue;
    VOID *dummy = NULL;
    if (Interface(h, &PciGuid, &dummy) == EFI_SUCCESS) continue;
    if (!GopOnTarget(h)) continue;
    if (t->BootServices->ConnectController) {
      EFI_STATUS cs = t->BootServices->ConnectController(h, NULL, NULL, TRUE);
      GuLog("Layer 1 child GOP connect: handle=%#llx status=%#llx\n",
            (unsigned long long)(UINTN)h, (unsigned long long)cs);
    }
  }
  if (t->BootServices->FreePool) (VOID)t->BootServices->FreePool(handles);
}

static BOOLEAN TryBindStagedVbiosEfiGop(EFI_SYSTEM_TABLE *t, EFI_HANDLE image, EFI_HANDLE pci_handle) {
  const UINT8 *payload = NULL;
  UINTN payload_bytes = 0;
  UINT16 machine_type = 0;
  BOOLEAN compressed = FALSE;
  if (!GuGetStagedVbiosEfiImage(&payload, &payload_bytes, &machine_type, &compressed) ||
      !payload || !payload_bytes) {
    GuLog("Layer 1 VBIOS GOP: no staged image available\n");
    return FALSE;
  }

  UINT8 *pe_buf = NULL;
  UINTN pe_size = 0;
  BOOLEAN decompressed_alloc = FALSE;

  if (compressed) {
    EFI_STATUS ds = DecompressVbiosEfiPayload(t, payload, payload_bytes, &pe_buf, &pe_size);
    if (ds != EFI_SUCCESS || !pe_buf || !pe_size) {
      GuLog("Layer 1 VBIOS GOP decompression failed: %#llx\n", (unsigned long long)ds);
      return FALSE;
    }
    decompressed_alloc = TRUE;
  } else {
    pe_buf = (UINT8 *)payload;
    pe_size = payload_bytes;
  }

  if (!ValidatePeImage(pe_buf, pe_size)) {
    GuLog("Layer 1 VBIOS GOP PE validation failed (size=%zu)\n", pe_size);
    if (decompressed_alloc && t->BootServices && t->BootServices->FreePool) {
      (VOID)t->BootServices->FreePool(pe_buf);
    }
    return FALSE;
  }

  GU_IN_MEMORY_DEVICE_PATH dp;
  memset(&dp, 0, sizeof(dp));
  dp.Mem.Header.Type = HARDWARE_DEVICE_PATH;
  dp.Mem.Header.SubType = HW_MEMMAP_DP;
  dp.Mem.Header.Length[0] = (UINT8)(sizeof(MEMMAP_DEVICE_PATH) & 0xFF);
  dp.Mem.Header.Length[1] = (UINT8)((sizeof(MEMMAP_DEVICE_PATH) >> 8) & 0xFF);
  dp.Mem.MemoryType = EfiBootServicesCode;
  dp.Mem.StartingAddress = (EFI_PHYSICAL_ADDRESS)(UINTN)pe_buf;
  dp.Mem.EndingAddress = (EFI_PHYSICAL_ADDRESS)((UINTN)pe_buf + pe_size);
  dp.End.Type = END_DEVICE_PATH_TYPE;
  dp.End.SubType = END_ENTIRE_DEVICE_PATH_SUBTYPE;
  dp.End.Length[0] = 4;
  dp.End.Length[1] = 0;

  EFI_HANDLE drv_image = NULL;
  EFI_STATUS s = t->BootServices->LoadImage(
      FALSE, image, (EFI_DEVICE_PATH_PROTOCOL *)&dp,
      (VOID *)pe_buf, pe_size, &drv_image);
  if (s != EFI_SUCCESS || !drv_image) {
    GuLog("Layer 1 VBIOS GOP LoadImage failed: %#llx\n", (unsigned long long)s);
    if (decompressed_alloc && t->BootServices && t->BootServices->FreePool) {
      (VOID)t->BootServices->FreePool(pe_buf);
    }
    return FALSE;
  }

  s = t->BootServices->StartImage(drv_image, NULL, NULL);
  GuLog("Layer 1 VBIOS GOP StartImage: %#llx\n", (unsigned long long)s);

  if (decompressed_alloc && t->BootServices && t->BootServices->FreePool) {
    (VOID)t->BootServices->FreePool(pe_buf);
    decompressed_alloc = FALSE;
  }

  if (s != EFI_SUCCESS) {
    return FALSE;
  }

  EFI_DRIVER_BINDING_PROTOCOL *binding = NULL;
  (VOID)Interface(drv_image, &BindingGuid, (VOID **)&binding);

  if (!binding && t->BootServices->LocateHandleBuffer) {
    EFI_HANDLE *bhandles = NULL;
    UINTN bcount = 0;
    if (t->BootServices->LocateHandleBuffer(ByProtocol, &BindingGuid, NULL, &bcount, &bhandles) == EFI_SUCCESS && bhandles) {
      for (UINTN bi = 0; bi < bcount; bi++) {
        EFI_DRIVER_BINDING_PROTOCOL *candidate = NULL;
        if (Interface(bhandles[bi], &BindingGuid, (VOID **)&candidate) == EFI_SUCCESS && candidate) {
          if (candidate->ImageHandle == drv_image) {
            binding = candidate;
            break;
          }
        }
      }
      if (t->BootServices->FreePool) (VOID)t->BootServices->FreePool(bhandles);
    }
  }

  if (binding && binding->Supported && binding->Start) {
    s = binding->Supported(binding, pci_handle, NULL);
    GuLog("Layer 1 DriverBinding Supported: %#llx\n", (unsigned long long)s);
    if (s == EFI_SUCCESS) {
      s = binding->Start(binding, pci_handle, NULL);
      GuLog("Layer 1 DriverBinding Start: %#llx\n", (unsigned long long)s);
      if (s == EFI_SUCCESS) {
        ConnectChildGopHandles(t, pci_handle);
        return TRUE;
      }
    }
  }

  return FALSE;
}

static UINTN CountLinearGops(VOID) {
  EFI_BOOT_SERVICES *b = Plan.table ? Plan.table->BootServices : NULL;
  if (!b || !b->LocateHandleBuffer) return 0;
  EFI_HANDLE *handles = NULL;
  UINTN count = 0, linear = 0;
  if (b->LocateHandleBuffer(ByProtocol, &GopGuid, NULL, &count, &handles) != EFI_SUCCESS || !handles)
    return 0;
  for (UINTN i = 0; i < count; i++) {
    EFI_GRAPHICS_OUTPUT_PROTOCOL *gop = NULL;
    if (Interface(handles[i], &GopGuid, (VOID **)&gop) == EFI_SUCCESS && gop && gop->Mode && gop->Mode->Info) {
      if (gop->Mode->FrameBufferBase != 0 && gop->Mode->FrameBufferSize != 0 &&
          gop->Mode->Info->PixelFormat != PixelBltOnly) {
        linear++;
      }
    }
  }
  if (b->FreePool) (VOID)b->FreePool(handles);
  return linear;
}

static EFI_GRAPHICS_OUTPUT_MODE_INFORMATION FallbackInfo = {
  0,
  1024,
  768,
  PixelBlueGreenRedReserved8BitPerColor,
  { 0, 0, 0, 0 },
  1024
};

static EFI_GRAPHICS_OUTPUT_PROTOCOL_MODE FallbackMode = {
  1,
  0,
  &FallbackInfo,
  sizeof(FallbackInfo),
  0,
  0
};

static EFI_STATUS EFIAPI FallbackGopQueryMode(
    EFI_GRAPHICS_OUTPUT_PROTOCOL *This,
    UINT32 ModeNumber,
    UINTN *SizeOfInfo,
    EFI_GRAPHICS_OUTPUT_MODE_INFORMATION **Info) {
  if (!This || !SizeOfInfo || !Info || ModeNumber != 0) return EFI_INVALID_PARAMETER;
  if (!Plan.table || !Plan.table->BootServices || !Plan.table->BootServices->AllocatePool) return EFI_UNSUPPORTED;
  VOID *copy = NULL;
  EFI_STATUS s = Plan.table->BootServices->AllocatePool(EfiBootServicesData, sizeof(FallbackInfo), &copy);
  if (s != EFI_SUCCESS || !copy) return EFI_OUT_OF_RESOURCES;
  memcpy(copy, &FallbackInfo, sizeof(FallbackInfo));
  *SizeOfInfo = sizeof(FallbackInfo);
  *Info = (EFI_GRAPHICS_OUTPUT_MODE_INFORMATION *)copy;
  return EFI_SUCCESS;
}

static EFI_STATUS EFIAPI FallbackGopSetMode(
    EFI_GRAPHICS_OUTPUT_PROTOCOL *This,
    UINT32 ModeNumber) {
  if (!This || ModeNumber != 0) return EFI_UNSUPPORTED;
  if (FallbackMode.FrameBufferBase && FallbackMode.FrameBufferSize) {
    memset((VOID *)(UINTN)FallbackMode.FrameBufferBase, 0, FallbackMode.FrameBufferSize);
  }
  return EFI_SUCCESS;
}

static EFI_STATUS EFIAPI FallbackGopBlt(
    EFI_GRAPHICS_OUTPUT_PROTOCOL *This,
    EFI_GRAPHICS_OUTPUT_BLT_PIXEL *BltBuffer,
    EFI_GRAPHICS_OUTPUT_BLT_OPERATION BltOperation,
    UINTN SourceX, UINTN SourceY,
    UINTN DestinationX, UINTN DestinationY,
    UINTN Width, UINTN Height, UINTN Delta) {
  if (!This || !FallbackMode.FrameBufferBase) return EFI_DEVICE_ERROR;
  if (Width == 0 || Height == 0) return EFI_INVALID_PARAMETER;
  UINTN fb_w = FallbackInfo.HorizontalResolution;
  UINTN fb_h = FallbackInfo.VerticalResolution;
  UINT32 *fb = (UINT32 *)(UINTN)FallbackMode.FrameBufferBase;

  if (BltOperation == EfiBltVideoFill) {
    if (!BltBuffer) return EFI_INVALID_PARAMETER;
    if (DestinationX + Width > fb_w || DestinationY + Height > fb_h) return EFI_INVALID_PARAMETER;
    UINT32 pixel = *(UINT32 *)BltBuffer;
    for (UINTN y = 0; y < Height; y++) {
      UINT32 *dst_line = fb + (DestinationY + y) * fb_w + DestinationX;
      for (UINTN x = 0; x < Width; x++) dst_line[x] = pixel;
    }
    return EFI_SUCCESS;
  }
  if (BltOperation == EfiBltBufferToVideo) {
    if (!BltBuffer) return EFI_INVALID_PARAMETER;
    if (DestinationX + Width > fb_w || DestinationY + Height > fb_h) return EFI_INVALID_PARAMETER;
    UINTN src_stride = Delta ? Delta / sizeof(UINT32) : Width;
    for (UINTN y = 0; y < Height; y++) {
      UINT32 *dst_line = fb + (DestinationY + y) * fb_w + DestinationX;
      const UINT32 *src_line = (const UINT32 *)BltBuffer + (SourceY + y) * src_stride + SourceX;
      for (UINTN x = 0; x < Width; x++) dst_line[x] = src_line[x];
    }
    return EFI_SUCCESS;
  }
  if (BltOperation == EfiBltVideoToBltBuffer) {
    if (!BltBuffer) return EFI_INVALID_PARAMETER;
    if (SourceX + Width > fb_w || SourceY + Height > fb_h) return EFI_INVALID_PARAMETER;
    UINTN dst_stride = Delta ? Delta / sizeof(UINT32) : Width;
    for (UINTN y = 0; y < Height; y++) {
      const UINT32 *src_line = fb + (SourceY + y) * fb_w + SourceX;
      UINT32 *dst_line = (UINT32 *)BltBuffer + (DestinationY + y) * dst_stride + DestinationX;
      for (UINTN x = 0; x < Width; x++) dst_line[x] = src_line[x];
    }
    return EFI_SUCCESS;
  }
  if (BltOperation == EfiBltVideoToVideo) {
    if (SourceX + Width > fb_w || SourceY + Height > fb_h ||
        DestinationX + Width > fb_w || DestinationY + Height > fb_h) return EFI_INVALID_PARAMETER;
    for (UINTN y_idx = 0; y_idx < Height; y_idx++) {
      UINTN y = (DestinationY <= SourceY) ? y_idx : (Height - 1 - y_idx);
      UINT32 *dst_line = fb + (DestinationY + y) * fb_w + DestinationX;
      const UINT32 *src_line = fb + (SourceY + y) * fb_w + SourceX;
      if (dst_line == src_line) continue;
      if (DestinationX <= SourceX) {
        for (UINTN x = 0; x < Width; x++) dst_line[x] = src_line[x];
      } else {
        for (UINTN x = Width; x > 0; x--) dst_line[x - 1] = src_line[x - 1];
      }
    }
    return EFI_SUCCESS;
  }
  return EFI_INVALID_PARAMETER;
}

static EFI_GRAPHICS_OUTPUT_PROTOCOL FallbackGop = {
  FallbackGopQueryMode,
  FallbackGopSetMode,
  FallbackGopBlt,
  &FallbackMode
};

static EFI_HANDLE FallbackHandle = NULL;

static EFI_STATUS InstallFallbackGop(EFI_SYSTEM_TABLE *t) {
  if (FallbackHandle) return EFI_SUCCESS;
  if (!t || !t->BootServices || !t->BootServices->AllocatePages ||
      !t->BootServices->InstallMultipleProtocolInterfaces) {
    return EFI_UNSUPPORTED;
  }

  UINTN pages = (1024U * 768U * 4U + 4095U) / 4096U;
  EFI_PHYSICAL_ADDRESS fb_addr = 0xFFFFFFFFULL;
  EFI_STATUS s = t->BootServices->AllocatePages(AllocateMaxAddress, EfiReservedMemoryType, pages, &fb_addr);
  if (s != EFI_SUCCESS) {
    s = t->BootServices->AllocatePages(AllocateAnyPages, EfiReservedMemoryType, pages, &fb_addr);
  }
  if (s != EFI_SUCCESS || fb_addr == 0) {
    GuLog("Fallback GOP: AllocatePages failed (%#llx)\n", (unsigned long long)s);
    return s != EFI_SUCCESS ? s : EFI_OUT_OF_RESOURCES;
  }

  memset((VOID *)(UINTN)fb_addr, 0, pages * 4096U);
  FallbackMode.FrameBufferBase = fb_addr;
  FallbackMode.FrameBufferSize = 1024U * 768U * 4U;
  FallbackMode.Info = &FallbackInfo;
  FallbackMode.SizeOfInfo = sizeof(FallbackInfo);
  FallbackMode.MaxMode = 1;
  FallbackMode.Mode = 0;

  static EFI_GUID FallbackGuid = { 0x9f5c4b1a, 0x738d, 0x4e6b, { 0x8a, 0x12, 0xd0, 0x3f, 0x7a, 0x5b, 0x9c, 0x11 } };
  static GU_FALLBACK_GOP_DEVICE_PATH FallbackDp;
  FallbackDp.Vendor.Header.Type = HARDWARE_DEVICE_PATH;
  FallbackDp.Vendor.Header.SubType = HW_VENDOR_DP;
  FallbackDp.Vendor.Header.Length[0] = (UINT8)(sizeof(VENDOR_DEVICE_PATH) & 0xFF);
  FallbackDp.Vendor.Header.Length[1] = (UINT8)((sizeof(VENDOR_DEVICE_PATH) >> 8) & 0xFF);
  FallbackDp.Vendor.Guid = FallbackGuid;
  FallbackDp.End.Type = END_DEVICE_PATH_TYPE;
  FallbackDp.End.SubType = END_ENTIRE_DEVICE_PATH_SUBTYPE;
  FallbackDp.End.Length[0] = 4;
  FallbackDp.End.Length[1] = 0;

  s = t->BootServices->InstallMultipleProtocolInterfaces(
      &FallbackHandle,
      &GopGuid, &FallbackGop,
      &PathGuid, &FallbackDp,
      NULL);
  if (s == EFI_SUCCESS && FallbackHandle && t->BootServices->ConnectController) {
    (VOID)t->BootServices->ConnectController(FallbackHandle, NULL, NULL, TRUE);
  }
  return s;
}

EFI_STATUS GuReconnectDisplayAfterUnlock(EFI_SYSTEM_TABLE *t, EFI_HANDLE image,
                                         EFI_HANDLE pci_handle, BOOLEAN allow_fallback_gop) {
  if (!Plan.csm_video) {
    if (t && t->BootServices && t->BootServices->ConnectController && pci_handle) {
      (VOID)t->BootServices->ConnectController(pci_handle, NULL, NULL, TRUE);
    }
    if (t && t->BootServices && t->BootServices->ConnectController && t->ConsoleOutHandle) {
      (VOID)t->BootServices->ConnectController(t->ConsoleOutHandle, NULL, NULL, TRUE);
    }
    if (t && t->BootServices && t->BootServices->Stall) {
      t->BootServices->Stall(200000);
    }
    if (t && t->ConOut && t->ConOut->Reset) {
      (VOID)t->ConOut->Reset(t->ConOut, FALSE);
    }
    GuReleaseStagedVbiosEfiImage();
    return EFI_SUCCESS;
  }

  GuLog("CSM display reconnect: bypassing legacy CsmVideo connect on PCI handle %#llx\n",
        (unsigned long long)(UINTN)pci_handle);

  BOOLEAN layer1_ok = TryBindStagedVbiosEfiGop(t, image, pci_handle);
  GuLog("CSM display reconnect: Layer 1 VBIOS Option ROM GOP bind result=%u\n", (unsigned)layer1_ok);

  UINTN linear_gops = CountLinearGops();
  GuLog("CSM display reconnect: linear GOP count=%zu\n", (size_t)linear_gops);

  if (linear_gops == 0 && allow_fallback_gop) {
    EFI_STATUS fb_status = InstallFallbackGop(t);
    GuLog("CSM display reconnect: Layer 2 fallback GOP installation result=%#llx\n",
          (unsigned long long)fb_status);
  }

  if (t && t->BootServices && t->BootServices->ConnectController && t->ConsoleOutHandle) {
    (VOID)t->BootServices->ConnectController(t->ConsoleOutHandle, NULL, NULL, TRUE);
  }
  if (t && t->BootServices && t->BootServices->Stall) {
    t->BootServices->Stall(200000);
  }
  if (t && t->ConOut && t->ConOut->Reset) {
    (VOID)t->ConOut->Reset(t->ConOut, FALSE);
  }
  GuReleaseStagedVbiosEfiImage();
  return EFI_SUCCESS;
}

